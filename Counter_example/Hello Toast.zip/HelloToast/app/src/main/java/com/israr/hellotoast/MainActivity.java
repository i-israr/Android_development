package com.israr.hellotoast;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int countValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final TextView ans = (TextView) findViewById(R.id.countlayout);
        if(savedInstanceState != null){
            countValue = savedInstanceState.getInt("countValue");
            ans.setText(""+ countValue);
        }

    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        // Save UI state changes to the savedInstanceState.
        // This bundle will be passed to onCreate if the process is
        // killed and restarted.
        savedInstanceState.putInt("countValue", countValue);


    }

    public void btnClick(View view){
        final TextView ans = (TextView) findViewById(R.id.countlayout);
        ans.setText(""+ ++countValue);
    }
//    @Override
//    public void onRestoreInstanceState(Bundle savedInstanceState) {
//        super.onRestoreInstanceState(savedInstanceState);
//        countValue = savedInstanceState.getInt("countValue");
//
//    }





}