package com.israr.dollartopkr;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public void btnClick(View view){
        Log.i("this", "This is a new message");
        EditText dollerAmount=findViewById(R.id.dollerAmount);
        String temp=dollerAmount.getText().toString();
        int value=0;
        if (!"".equals(temp)){
            value=Integer.parseInt(temp);
        }
        int doubleInr = 163 * value;

        System.out.println(doubleInr);

//        TextView converted = new TextView(this);
//        converted.setText(Integer.toString(doubleInr));

        final TextView converted = (TextView) findViewById(R.id.converted);
        converted.setText(""+doubleInr+" PKR");

        //        converted.setText(""+doubleInr);




//        EditText dollarAmount = (EditText) findViewById(R.id.dollarAmount);
//        String dollars = dollarAmount.getText().toString();
//        Double doubleDollars = Double.parseDouble(dollars);
//        Double doubleInr = 71.72 * doubleDollars;
//        String toastText = "= " + doubleInr.toString() + " $";
//        Toast.makeText(this, toastText, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}