package com.israr.mid_exam_pre;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class OptActivity extends AppCompatActivity {

    Button add,sub,mult,divide;
    int result=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opt);
        add= findViewById(R.id.add);
        sub= findViewById(R.id.sub);
        mult= findViewById(R.id.multiply);
        divide= findViewById(R.id.divide);


        final int fValue = getIntent().getExtras().getInt("firstNo");
        final int sValue = getIntent().getExtras().getInt("secondNo");

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                result= fValue+sValue;
                Intent returnIntent = new Intent();
                returnIntent.putExtra("result",result);
                setResult(MainActivity.RESULT_OK,returnIntent);
                finish();
            }
        });

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                result= fValue-sValue;
                Intent returnIntent = new Intent();
                returnIntent.putExtra("result",result);
                setResult(MainActivity.RESULT_OK,returnIntent);
                finish();
            }
        });

        mult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                result= fValue*sValue;
                Intent returnIntent = new Intent();
                returnIntent.putExtra("result",result);
                setResult(MainActivity.RESULT_OK,returnIntent);
                finish();
            }
        });

        divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                result= fValue/sValue;
                Intent returnIntent = new Intent();
                returnIntent.putExtra("result",result);
                setResult(MainActivity.RESULT_OK,returnIntent);
                finish();
            }
        });
    }
}