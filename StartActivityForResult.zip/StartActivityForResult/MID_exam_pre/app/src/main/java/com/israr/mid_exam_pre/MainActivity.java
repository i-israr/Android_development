package com.israr.mid_exam_pre;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final int REQUEST_CODE = 1;
    EditText firstNo,secondNo;
    Button operation;
    TextView result;
    int fst=0,snd=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        firstNo= findViewById(R.id.firstNo);
        secondNo= findViewById(R.id.secondNo);
        operation= findViewById(R.id.action);
        result= findViewById(R.id.textView3);

        operation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getVal();
                Intent intent = new Intent(MainActivity.this, OptActivity.class);
                intent.putExtra("firstNo",fst);
                intent.putExtra("secondNo",snd );
                startActivityForResult(intent , REQUEST_CODE);
            }
        });
    }


    private void getVal(){
        fst= Integer.parseInt(firstNo.getText().toString().trim());
        snd= Integer.parseInt(secondNo.getText().toString().trim());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            super.onActivityResult(requestCode, resultCode, data);

            if (requestCode == REQUEST_CODE  && resultCode  == RESULT_OK) {

                String requiredValue = String.valueOf(data.getIntExtra("result",0));

                result.setText(requiredValue);
            }
        } catch (Exception ex) {
            Toast.makeText(MainActivity.this, ex.toString(),
                    Toast.LENGTH_SHORT).show();
        }
    }
}